#!/bin/python3
import platform
import subprocess

ip_list = []


def ping(base_ip, start, end):
    #determin os
    param = '-n' if platform.system() == 'Windows' else '-c'
    #build the cmd and return ips
    start = int(start)
    end = int(end)
    for i in range(start, end):
        ip = f"{base_ip}.{str(i)}"
        command = ['ping', param, '1', ip , '-W', '1']
        #execute cmd
        res = subprocess.call(command, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)

        if res == 0:
            #print(f"Ping {ip} succeeded")
            ip_list.append(ip)
        #else:
            #print(f"Ping {ip} failed")
    return ip_list

#run
#ping(input("Enter first 3 octets of IP range: "), input("range start: "), input("range end: "))
#print(ip_list)
