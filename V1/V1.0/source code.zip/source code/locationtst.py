#!/bin/python3

import tkinter as tk

root = tk.Tk()
root.title("Network Map")
canvas = tk.Canvas(root, height=800, width=600, bg='black')
canvas.pack()

# draw rtr (top-left-x, top-left-y, bottom-right-x, bottom right y)
#canvas.create_oval(200, 250, 500, 550, fill='red', outline='white')
canvas.create_oval(325, 275, 275, 325, fill='red', outline='white')
canvas.create_text(400, 100, text="Rtr", fill='white')


root.mainloop()




